# movie-plot-genre-predictor
Training a Transformer model to predict movie genres

https://www.youtube.com/watch?v=Gme2lw7xRfc&ab_channel=langfab
